def hello_world(name=None):
    if name==None:
        print("Hello World")
    else:
        print(f"Hello {name}")