Install the package with:
```
pip install Hello-World
```

Import the package by:
```
from helloworld import hello_world
```

Sample usage:
```
hello_world('Everyone')
```

Output:
Hello Everyone